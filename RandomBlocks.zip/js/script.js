var workspace = Blockly.inject('blocklyDiv', {
    toolbox: `<xml>
        <category name="Logic" colour="%{BKY_LOGIC_HUE}">
            <block type="controls_if"></block>
        </category>
        <category name="Loops" colour="%{BKY_LOOPS_HUE}">
            <block type="controls_repeat_ext">
                <value name="TIMES">
                    <shadow type="math_number">
                        <field name="NUM">10</field>
                    </shadow>
                </value>
            </block>
        </category>
        <category name="Variables" custom="VARIABLE" colour="%{BKY_VARIABLES_HUE}"></category>
    </xml>`
});
